import { Link } from "react-router-dom";

const assignments = [
  {
    id: 1,
    title: "Assignment 01",
    type: "REFLECTION",
    description:
      "Sustainability matters to me because the choices we make today directly affect the quality of life for future generations. As technology continues to evolve, the amount of electronic waste is increasing rapidly. Improper disposal of e-waste can pollute the environment, harm wildlife, and waste valuable natural resources. I believe that every individual has a responsibility to protect the environment by adopting sustainable habits and making informed decisions.\n\nTo contribute towards a greener future, I plan to practice responsible disposal and recycling of electronic waste through authorized collection centers. I will also focus on reducing unnecessary electronic purchases, repairing and reusing devices whenever possible, and spreading awareness about sustainable e-waste management among my family, friends, and community. By following the principles of Reduce, Reuse and Recycle, I hope to play my part in creating a cleaner and more sustainable environment.",
    image: "/assignments/images/assignment-01.jpeg",
    icon: "🌱",
  },
];

function Portfolio() {
  return (
    <main className="portfolio-page">
      <section className="portfolio-header">
        <p className="section-label">
          MY ACADEMIC WORK
        </p>

        <h1>
          Assignments &
          <span> Activities.</span>
        </h1>

        <p>
          A collection of my academic work related to e-waste,
          environmental sustainability and responsible technology.
        </p>
      </section>

      <section className="work-grid">
        {assignments.map((item) => (
          <article className="work-card" key={item.id}>

            <div className="card-top">

              <div className="card-icon">
                {item.icon}
              </div>

              <span className="card-number">
                {String(item.id).padStart(2, "0")}
              </span>

            </div>

            <img
              src={item.image}
              alt={item.title}
              className="assignment-image"
            />

            <div className="card-content">

              <p className="card-type">
                {item.type}
              </p>

              <h2>
                {item.title}
              </h2>

              <p
                style={{
                  whiteSpace: "pre-line",
                  textAlign: "justify",
                }}
              >
                {item.description}
              </p>

            </div>

            <a
              href={item.image}
              target="_blank"
              rel="noopener noreferrer"
              className="view-work"
            >
              View Full Image
              <span>↗</span>
            </a>

          </article>
        ))}
      </section>

      <section className="portfolio-note">

        <div className="note-icon">
          +
        </div>

        <div>
          <h3>
            More work coming soon
          </h3>

          <p>
            This portfolio will continue to grow as new assignments,
            activities and academic work are completed.
          </p>
        </div>

      </section>
    </main>
  );
}

export default Portfolio;