import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState } from "react";

import Home from "./pages/Home";
import Portfolio from "./pages/Portfolio";
import Student from "./pages/Student";
import About from "./pages/About";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="navbar">
      <a href="/" className="logo">
        <span>♻</span>
        <strong>Saurabh Lubal</strong>
      </a>

      <div className={`nav-links ${menuOpen ? "mobile-open" : ""}`}>
        <a href="/">Home</a>
        <a href="/portfolio">Portfolio</a>
        <a href="/student">Student</a>
        <a href="/about">About</a>
      </div>

      <button
        className={`menu-button ${menuOpen ? "active" : ""}`}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        <span></span>
        <span></span>
        <span></span>
      </button>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/student" element={<Student />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </BrowserRouter>
  );
}